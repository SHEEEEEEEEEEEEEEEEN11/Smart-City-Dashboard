# Smart City Dashboard

A real-time dashboard for monitoring air quality and traffic data in smart cities.

## Prerequisites

- [Node.js](https://nodejs.org/) (version 14 or higher)
- A modern web browser (Chrome, Firefox, Edge, etc.)

## Installation

1. Download or clone this repository to your computer
2. Open a terminal/command prompt
3. Navigate to the project directory:
   ```
   cd path/to/project
   ```
4. Install frontend dependencies:
   ```
   cd frontend
   npm install
   ```

## Running the Application

1. Place your data file:
   - Copy your `Merged_Air_Quality_and_Traffic_Data.csv` file into the `frontend/public` directory

2. Start the application:
   ```
   cd frontend
   npm start
   ```

3. Open your web browser and go to:
   ```
   http://localhost:3000
   ```

## Data File Format

Your CSV file should have the following columns:
- timestamp
- pm2_5
- pm10
- no2
- o3
- aqi
- distance_km
- duration_in_traffic_min

## Troubleshooting

1. If port 3000 is in use:
   - Create a file named `.env` in the `frontend` directory
   - Add the line: `PORT=3001` (or any other available port)
   - Restart the application

2. If you see "Error parsing CSV data":
   - Make sure your CSV file is in the correct format
   - Check that all columns are present
   - Verify there are no special characters in the column headers

## Building for Production

To create a production build:

1. Navigate to the frontend directory:
   ```
   cd frontend
   ```

2. Create a production build:
   ```
   npm run build
   ```

3. The build files will be in the `frontend/build` directory
4. You can deploy these files to any web server

## Support

If you encounter any issues:
1. Check the browser's developer console (F12) for error messages
2. Verify your CSV file format matches the required structure
3. Ensure all dependencies are properly installed

## License

MIT License - Feel free to use and modify as needed.
